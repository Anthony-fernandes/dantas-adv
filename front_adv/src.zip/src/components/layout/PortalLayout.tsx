import { useMemo, useState } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { DollarSign, FileText, Gavel, Home, LogOut, Menu, MessageSquare, Scale, Sparkles, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { buildBrandThemeStyle, firstText } from "@/lib/brandTheme";
import { cn } from "@/lib/utils";
import { leadService } from "@/services/api";

const portalNav = [
  { label: "Inicio", icon: Home, path: "/portal" },
  { label: "Processos", icon: Scale, path: "/portal/processos" },
  { label: "Documentos", icon: FileText, path: "/portal/documentos" },
  { label: "Financeiro", icon: DollarSign, path: "/portal/financeiro" },
  { label: "Mensagens", icon: MessageSquare, path: "/portal/mensagens" },
];

export function PortalLayout() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { logout, user } = useAuth();
  const publicSiteQuery = useQuery({
    queryKey: ["portal-layout-brand"],
    queryFn: async () => await leadService.getPublicSite(),
  });

  const payload = publicSiteQuery.data as any;
  const settings = payload?.settings;
  const themeStyle = useMemo(() => buildBrandThemeStyle(settings), [settings]);

  const brand = useMemo(() => {
    const companyName = firstText(payload?.company?.name, settings?.brand_name, "Portal do Cliente");
    const logoUrl = firstText(payload?.company?.logo_url);

    return {
      companyName: companyName || "Portal do Cliente",
      logoUrl,
    };
  }, [payload?.company?.logo_url, payload?.company?.name, settings?.brand_name]);

  const isActive = (path: string) => {
    if (path === "/portal") return location.pathname === "/portal";
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };

  function renderBrandMark() {
    if (brand.logoUrl) {
      return <img src={brand.logoUrl} alt={`Logo de ${brand.companyName}`} className="h-12 w-12 rounded-2xl object-cover" />;
    }

    return (
      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-white">
        <Gavel className="h-6 w-6" />
      </div>
    );
  }

  function renderNav(onNavigate?: () => void) {
    return (
      <nav className="space-y-2">
        {portalNav.map((item) => (
          <Link key={item.path} to={item.path} onClick={onNavigate}>
            <div
              className={cn(
                "flex items-center gap-3 rounded-2xl border px-4 py-3 text-sm font-medium transition-all",
                isActive(item.path)
                  ? "border-white/20 bg-white/14 text-white shadow-[0_18px_38px_-26px_rgba(15,23,42,0.9)]"
                  : "border-white/8 bg-white/[0.04] text-white/74 hover:border-white/14 hover:bg-white/[0.08] hover:text-white",
              )}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              <span>{item.label}</span>
            </div>
          </Link>
        ))}
      </nav>
    );
  }

  return (
    <div className="landing-theme min-h-screen text-white" style={themeStyle}>
      <div className="fixed inset-0 bg-[linear-gradient(135deg,var(--landing-hero-start),var(--landing-hero-mid),var(--landing-hero-end))]" />
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.12),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(201,171,118,0.12),transparent_22%),linear-gradient(180deg,rgba(6,13,36,0.14),rgba(6,13,36,0.52))]" />

      <aside className="fixed inset-y-5 left-5 z-40 hidden w-[292px] overflow-hidden rounded-[32px] border border-white/10 bg-[linear-gradient(180deg,rgba(8,20,52,0.9),rgba(7,15,38,0.95))] shadow-[0_30px_70px_-34px_rgba(2,6,23,0.95)] lg:flex lg:flex-col">
        <div className="border-b border-white/10 px-6 py-6">
          <div className="flex items-center gap-4">
            {renderBrandMark()}
            <div className="min-w-0">
              <p className="text-[0.68rem] font-semibold uppercase tracking-[0.22em]" style={{ color: "var(--landing-accent-strong)" }}>
                Portal do cliente
              </p>
              <p className="truncate font-display text-lg font-bold text-white">{brand.companyName}</p>
            </div>
          </div>

          <div className="mt-5 rounded-[24px] border border-white/10 bg-white/[0.05] px-4 py-4">
            <p className="text-sm font-semibold text-white">Acompanhamento com clareza</p>
            <p className="mt-2 text-sm leading-6 text-white/70">
              Consulte processos, documentos e mensagens em um ambiente visualmente alinhado com a landing principal.
            </p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-5">
          <p className="px-2 pb-3 text-[0.68rem] font-semibold uppercase tracking-[0.22em] text-white/48">Navegacao</p>
          {renderNav()}
        </div>

        <div className="border-t border-white/10 px-6 py-5">
          <div className="rounded-[24px] border border-white/10 bg-white/[0.05] px-4 py-4">
            <p className="text-[0.68rem] font-semibold uppercase tracking-[0.2em] text-white/50">Conta conectada</p>
            <p className="mt-2 truncate text-sm font-medium text-white">{user?.email || "Cliente"}</p>
          </div>

          <Button
            type="button"
            variant="ghost"
            onClick={logout}
            className="mt-4 h-12 w-full rounded-2xl border border-white/12 bg-white/[0.06] text-white hover:bg-white/[0.12] hover:text-white"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Button>
        </div>
      </aside>

      <header className="fixed inset-x-0 top-0 z-50 flex h-16 items-center justify-between border-b border-white/10 bg-[rgba(8,20,52,0.74)] px-4 backdrop-blur-xl lg:hidden">
        <div className="flex min-w-0 items-center gap-3">
          {renderBrandMark()}
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">Portal do cliente</p>
            <p className="truncate text-xs text-white/60">{brand.companyName}</p>
          </div>
        </div>

        <Button variant="ghost" size="sm" className="text-white hover:bg-white/10 hover:text-white" onClick={() => setMobileOpen((prev) => !prev)}>
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </header>

      {mobileOpen ? (
        <div className="fixed inset-0 z-40 bg-slate-950/45 lg:hidden" onClick={() => setMobileOpen(false)}>
          <aside
            className="h-full w-[288px] border-r border-white/10 bg-[linear-gradient(180deg,rgba(8,20,52,0.96),rgba(7,15,38,0.98))] px-4 py-4 shadow-xl"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                {renderBrandMark()}
                <div className="min-w-0">
                  <p className="truncate font-display text-base font-bold text-white">Portal do cliente</p>
                  <p className="truncate text-xs text-white/60">{brand.companyName}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/10 hover:text-white" onClick={() => setMobileOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="pt-4">{renderNav(() => setMobileOpen(false))}</div>

            <Button
              type="button"
              variant="ghost"
              onClick={logout}
              className="mt-6 h-12 w-full rounded-2xl border border-white/12 bg-white/[0.06] text-white hover:bg-white/[0.12] hover:text-white"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Sair
            </Button>
          </aside>
        </div>
      ) : null}

      <main className="relative px-4 pb-6 pt-20 sm:px-6 lg:ml-[324px] lg:px-8 lg:pb-8 lg:pt-6">
        <div className="rounded-[30px] border border-white/55 bg-white/94 p-4 text-slate-900 shadow-[0_28px_70px_-36px_rgba(2,6,23,0.9)] backdrop-blur-xl sm:p-6 lg:p-8">
          <div className="mb-6 rounded-[28px] bg-[linear-gradient(135deg,rgba(8,29,54,0.96),rgba(11,26,68,0.94),rgba(13,53,95,0.92))] px-5 py-5 text-white shadow-[0_24px_50px_-30px_rgba(2,6,23,0.88)] sm:px-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-3 py-1 text-[0.68rem] font-semibold uppercase tracking-[0.2em] text-white/78">
                  <Sparkles className="h-3.5 w-3.5" style={{ color: "var(--landing-accent-strong)" }} />
                  Area do cliente
                </div>
                <h1 className="mt-4 font-display text-3xl font-bold tracking-[-0.03em] text-white">Seu acompanhamento em um painel unico</h1>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-white/68">
                  Mantivemos a experiencia do portal mais consistente com a landing e os fluxos de acesso do projeto.
                </p>
              </div>

              <div className="rounded-[22px] border border-white/10 bg-white/[0.06] px-4 py-3 text-sm text-white/78">
                <p className="text-[0.68rem] font-semibold uppercase tracking-[0.2em] text-white/50">Conta atual</p>
                <p className="mt-1 font-medium text-white">{user?.email || "Cliente"}</p>
              </div>
            </div>
          </div>

          <Outlet />
        </div>
      </main>
    </div>
  );
}
