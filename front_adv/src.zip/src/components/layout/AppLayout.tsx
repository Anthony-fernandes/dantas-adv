import { Outlet, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { AppSidebar } from './AppSidebar';
import { Topbar } from './Topbar';
import { useAuth } from '@/contexts/AuthContext';
import { useTenant } from '@/contexts/TenantContext';

export function AppLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { isLoading, isSuperuser } = useAuth();
  const { activeTenantId, tenants, isLoadingTenants, setActiveTenant } = useTenant();

  useEffect(() => {
    if (!isLoading && !isLoadingTenants && !activeTenantId && tenants.length > 0) {
      setActiveTenant(tenants[0].id);
    }
  }, [isLoading, isLoadingTenants, activeTenantId, tenants, setActiveTenant]);

  if (isLoading || isLoadingTenants) return null;
  if (!activeTenantId && tenants.length > 0) return null;

  if (!activeTenantId && !isSuperuser) {
    if (tenants?.length) return <Navigate to="/app/select-tenant" replace />;
    return <Navigate to="/app/setup" replace />;
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-white text-slate-900">
      <AppSidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <Topbar onOpenMenu={() => setMobileOpen(true)} />
        <main className="flex-1 overflow-y-auto px-4 py-4 sm:px-6 sm:py-6 lg:px-8">
          <div className="mx-auto w-full max-w-[1680px]">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
