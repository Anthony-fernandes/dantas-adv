import { Bell, Menu, Search } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useTenant } from '@/contexts/TenantContext';
import { TenantSwitcher } from '@/components/shared/TenantSwitcher';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useNotifications } from '@/hooks/useApiData';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

type TopbarProps = {
  onOpenMenu: () => void;
};

function resolvePageTitle(pathname: string) {
  if (pathname.startsWith('/app/processos')) return 'Processos';
  if (pathname.startsWith('/app/clientes')) return 'Clientes';
  if (pathname.startsWith('/app/documentos')) return 'Documentos';
  if (pathname.startsWith('/app/audiencias')) return 'Audiencias';
  if (pathname.startsWith('/app/agenda')) return 'Agenda';
  if (pathname.startsWith('/app/financeiro')) return 'Financeiro';
  if (pathname.startsWith('/app/funcionarios')) return 'Funcionarios';
  if (pathname.startsWith('/app/cargos')) return 'Cargos';
  if (pathname.startsWith('/app/usuarios')) return 'Usuarios';
  if (pathname.startsWith('/app/empresas')) return 'Empresas';
  if (pathname.startsWith('/app/landing')) return 'Site institucional';
  if (pathname.startsWith('/app/blog')) return 'Blog';
  return 'Painel';
}

export function Topbar({ onOpenMenu }: TopbarProps) {
  const location = useLocation();
  const { profile, isSuperuser } = useAuth();
  const { tenants, activeTenant } = useTenant();
  const { data: notifications } = useNotifications(undefined, !isSuperuser);
  const unreadCount = notifications?.filter((n) => !n.read).length || 0;
  const initials = profile?.full_name?.split(' ').map((n) => n[0]).join('').slice(0, 2) || 'U';
  const pageTitle = resolvePageTitle(location.pathname);

  return (
    <header className="border-b border-slate-200 bg-white/95 backdrop-blur-sm">
      <div className="flex min-h-[72px] items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <div className="flex min-w-0 flex-1 items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 lg:hidden"
            onClick={onOpenMenu}
          >
            <Menu className="h-4 w-4" />
          </Button>

          <div className="min-w-0">
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">
              {activeTenant?.name || 'Sistema juridico'}
            </p>
            <h1 className="truncate font-display text-lg font-semibold text-slate-900">{pageTitle}</h1>
          </div>
        </div>

        <div className="hidden min-w-0 flex-1 items-center gap-3 lg:flex">
          {tenants.length > 0 ? <TenantSwitcher /> : null}
          <div className="relative max-w-xl flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              placeholder="Buscar processos, clientes, documentos..."
              className="h-10 rounded-xl border-slate-200 bg-white pl-10 shadow-none focus-visible:ring-1 focus-visible:ring-slate-300"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm" className="relative h-10 rounded-lg px-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 ? (
                  <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-slate-900 text-[10px] font-bold text-white">
                    {unreadCount}
                  </span>
                ) : null}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="end">
              <div className="border-b border-slate-200 p-3 text-sm font-semibold text-slate-900">Notificacoes</div>
              <div className="max-h-64 overflow-y-auto">
                {notifications && notifications.length > 0 ? (
                  notifications.slice(0, 10).map((n) => (
                    <div key={n.id} className={`border-b border-slate-100 p-3 text-sm ${n.read ? 'opacity-60' : ''}`}>
                      <p className="font-medium text-slate-900">{n.title}</p>
                      {n.message ? <p className="mt-0.5 text-xs text-slate-500">{n.message}</p> : null}
                      <p className="mt-1 text-[10px] text-slate-400">{new Date(n.created_at).toLocaleString('pt-BR')}</p>
                    </div>
                  ))
                ) : (
                  <p className="p-4 text-center text-sm text-slate-500">Nenhuma notificacao</p>
                )}
              </div>
            </PopoverContent>
          </Popover>

          <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5">
            <Avatar className="h-8 w-8 border border-slate-200">
              <AvatarFallback className="bg-slate-800 text-xs font-semibold text-white">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="hidden min-w-0 md:block">
              <p className="truncate text-sm font-medium text-slate-900">{profile?.full_name || 'Usuario'}</p>
              <p className="truncate text-xs text-slate-500">{profile?.email || 'Equipe interna'}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-slate-200 px-4 py-3 lg:hidden">
        <div className="flex flex-col gap-3">
          {tenants.length > 0 ? <TenantSwitcher /> : null}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              placeholder="Buscar processos, clientes, documentos..."
              className="h-10 rounded-xl border-slate-200 bg-white pl-10 shadow-none focus-visible:ring-1 focus-visible:ring-slate-300"
            />
          </div>
        </div>
      </div>
    </header>
  );
}
