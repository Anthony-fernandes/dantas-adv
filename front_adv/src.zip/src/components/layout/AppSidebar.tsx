import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { useQuery } from "@tanstack/react-query";
import { leadService } from "@/services/api";
import {
  BookOpenText,
  LayoutDashboard,
  Users,
  DollarSign,
  Building2,
  BriefcaseBusiness,
  UserCog,
  UserSquare2,
  ChevronLeft,
  ChevronRight,
  Gavel,
  Globe2,
  LogOut,
  FolderKanban,
  CalendarDays,
  FileStack,
  FolderOpen,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type NavItem = { label: string; icon: any; path: string; roles?: string[] };
type NavSection = { title: string; items: NavItem[] };

type AppSidebarProps = {
  mobileOpen: boolean;
  onClose: () => void;
};

const navSections: NavSection[] = [
  {
    title: "Geral",
    items: [{ label: "Painel", icon: LayoutDashboard, path: "/app/dashboard" }],
  },
  {
    title: "Juridico",
    items: [
      { label: "Clientes", icon: Users, path: "/app/clientes", roles: ["OWNER", "ADMIN", "LAWYER", "ASSISTANT"] },
      { label: "Processos", icon: Gavel, path: "/app/processos", roles: ["OWNER", "ADMIN", "LAWYER", "ASSISTANT"] },
      { label: "Areas de atuacao", icon: FolderKanban, path: "/app/areas", roles: ["OWNER", "ADMIN", "LAWYER", "ASSISTANT"] },
      { label: "Documentos", icon: FileStack, path: "/app/documentos", roles: ["OWNER", "ADMIN", "LAWYER", "ASSISTANT"] },
      { label: "Audiencias", icon: FolderOpen, path: "/app/audiencias", roles: ["OWNER", "ADMIN", "LAWYER", "ASSISTANT"] },
      { label: "Agenda", icon: CalendarDays, path: "/app/agenda", roles: ["OWNER", "ADMIN", "LAWYER", "ASSISTANT"] },
    ],
  },
  {
    title: "Financeiro",
    items: [{ label: "Financeiro", icon: DollarSign, path: "/app/financeiro", roles: ["OWNER", "ADMIN", "FINANCE"] }],
  },
  {
    title: "Cadastros",
    items: [
      { label: "Funcionarios", icon: UserSquare2, path: "/app/funcionarios", roles: ["OWNER", "ADMIN"] },
      { label: "Cargos", icon: BriefcaseBusiness, path: "/app/cargos", roles: ["OWNER", "ADMIN"] },
      { label: "Usuarios", icon: UserCog, path: "/app/usuarios", roles: ["OWNER", "ADMIN"] },
      { label: "Empresas", icon: Building2, path: "/app/empresas", roles: ["OWNER", "ADMIN"] },
      { label: "Site institucional", icon: Globe2, path: "/app/landing", roles: ["OWNER", "ADMIN"] },
      { label: "Blog", icon: BookOpenText, path: "/app/blog", roles: ["OWNER", "ADMIN"] },
    ],
  },
];

export function AppSidebar({ mobileOpen, onClose }: AppSidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const { profile, roles, hasRole, logout } = useAuth();
  const { activeTenant } = useTenant();
  const publicSiteQuery = useQuery({
    queryKey: ["sidebar-public-site-brand"],
    queryFn: async () => await leadService.getPublicSite(),
  });

  const companyName =
    String(activeTenant?.name || "").trim() ||
    String((publicSiteQuery.data as any)?.company?.name || "").trim() ||
    "JurisFlow";
  const companyLogo = String((publicSiteQuery.data as any)?.company?.logo_url || "").trim();

  function renderBrand() {
    if (companyLogo) {
      return <img src={companyLogo} alt="Logo da empresa" className="h-9 w-9 rounded-lg object-cover border border-white/10" />;
    }
    return (
      <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-200">
        <Gavel className="h-4 w-4" />
      </div>
    );
  }

  function renderSections(onNavigate?: () => void) {
    return navSections.map((section) => {
      const visibleItems = section.items.filter((item) => (item.roles ? hasRole(...(item.roles as any)) : true));
      if (visibleItems.length === 0) return null;

      return (
        <div key={section.title} className="space-y-1.5">
          {!collapsed && (
            <p className="px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">
              {section.title}
            </p>
          )}
          {visibleItems.map((item) => {
            const isActive = location.pathname.startsWith(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={onNavigate}
                title={collapsed ? item.label : undefined}
                className={cn(
                  "flex items-center gap-3 rounded-xl border px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "border-white/10 bg-white/10 text-white"
                    : "border-transparent text-slate-300 hover:border-white/8 hover:bg-white/5 hover:text-white",
                )}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!collapsed ? <span className="truncate">{item.label}</span> : null}
              </Link>
            );
          })}
        </div>
      );
    });
  }

  const desktopWidth = collapsed ? "lg:w-[84px]" : "lg:w-[272px]";

  return (
    <>
      <aside
        className={cn(
          "hidden h-screen flex-col border-r border-slate-800 bg-[#111827] text-slate-100 lg:flex",
          desktopWidth,
        )}
      >
        <div className="flex h-16 items-center border-b border-white/8 px-4">
          <div className="flex min-w-0 items-center gap-3">
            {renderBrand()}
            {!collapsed ? (
              <div className="min-w-0">
                <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">Sistema juridico</p>
                <p className="truncate font-display text-sm font-semibold text-white">{companyName}</p>
              </div>
            ) : null}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
          {renderSections()}
        </div>

        <div className="border-t border-white/8 p-3">
          {!collapsed && profile ? (
            <div className="mb-3 rounded-xl border border-white/8 bg-white/5 px-3 py-3">
              <p className="truncate text-sm font-medium text-white">{profile.full_name}</p>
              <p className="mt-1 truncate text-xs text-slate-400">{roles.join(", ")}</p>
            </div>
          ) : null}

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="flex-1 justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-white"
              onClick={() => setCollapsed((prev) => !prev)}
            >
              {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </Button>
            {!collapsed ? (
              <Button
                variant="ghost"
                size="sm"
                className="rounded-lg text-slate-300 hover:bg-white/5 hover:text-white"
                onClick={logout}
              >
                <LogOut className="h-4 w-4" />
              </Button>
            ) : null}
          </div>
        </div>
      </aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-50 bg-slate-950/40 lg:hidden" onClick={onClose}>
          <aside
            className="flex h-full w-[292px] flex-col border-r border-slate-800 bg-[#111827] text-slate-100"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex h-16 items-center justify-between border-b border-white/8 px-4">
              <div className="flex min-w-0 items-center gap-3">
                {renderBrand()}
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-400">Sistema juridico</p>
                  <p className="truncate font-display text-sm font-semibold text-white">{companyName}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-slate-300 hover:bg-white/5 hover:text-white" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
              {renderSections(onClose)}
            </div>

            <div className="border-t border-white/8 p-3">
              {profile ? (
                <div className="mb-3 rounded-xl border border-white/8 bg-white/5 px-3 py-3">
                  <p className="truncate text-sm font-medium text-white">{profile.full_name}</p>
                  <p className="mt-1 truncate text-xs text-slate-400">{roles.join(", ")}</p>
                </div>
              ) : null}

              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-center rounded-lg text-slate-300 hover:bg-white/5 hover:text-white"
                onClick={logout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Sair
              </Button>
            </div>
          </aside>
        </div>
      ) : null}
    </>
  );
}
