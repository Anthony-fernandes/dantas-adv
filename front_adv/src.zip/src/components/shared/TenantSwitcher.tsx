import { Building2, Check, ChevronsUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { useTenant } from '@/contexts/TenantContext';
import { cn } from '@/lib/utils';

export function TenantSwitcher() {
  const { tenants, activeTenantId, setActiveTenant } = useTenant();
  const active = tenants.find((t) => t.id === activeTenantId);

  if (!tenants?.length) return null;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="justify-between gap-2 min-w-[220px]">
          <span className="flex items-center gap-2 truncate">
            <Building2 className="h-4 w-4" />
            <span className="truncate">{active?.name ?? 'Selecionar escritório'}</span>
          </span>
          <ChevronsUpDown className="h-4 w-4 opacity-60" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-[320px]" align="start">
        <Command>
          <CommandInput placeholder="Buscar escritório..." />
          <CommandList>
            <CommandEmpty>Nenhum escritório encontrado.</CommandEmpty>
            <CommandGroup heading="Escritórios">
              {tenants.map((t) => (
                <CommandItem
                  key={t.id}
                  value={t.name}
                  onSelect={() => setActiveTenant(t.id)}
                  className="flex items-center justify-between"
                >
                  <span className="truncate">{t.name}</span>
                  <Check className={cn('h-4 w-4', t.id === activeTenantId ? 'opacity-100' : 'opacity-0')} />
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
