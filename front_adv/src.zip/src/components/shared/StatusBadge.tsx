import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const statusBadgeVariants = cva(
  'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors',
  {
    variants: {
      variant: {
        default: 'bg-secondary text-secondary-foreground',
        active: 'bg-primary/10 text-primary',
        success: 'bg-success/10 text-success',
        warning: 'bg-warning/10 text-warning',
        destructive: 'bg-destructive/10 text-destructive',
        info: 'bg-info/10 text-info',
        muted: 'bg-muted text-muted-foreground',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  }
);

interface StatusBadgeProps extends VariantProps<typeof statusBadgeVariants> {
  children: React.ReactNode;
  className?: string;
  dot?: boolean;
}

export function StatusBadge({ children, variant, className, dot = true }: StatusBadgeProps) {
  return (
    <span className={cn(statusBadgeVariants({ variant }), className)}>
      {dot && (
        <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
      )}
      {children}
    </span>
  );
}

// Utility mappings
export const processStatusVariant = {
  ATIVO: 'active' as const,
  ENCERRADO: 'muted' as const,
  SUSPENSO: 'warning' as const,
  ARQUIVADO: 'muted' as const,
};

export const deadlineStatusVariant = {
  PENDENTE: 'warning' as const,
  CONCLUIDO: 'success' as const,
  ATRASADO: 'destructive' as const,
};

export const deadlinePriorityVariant = {
  BAIXA: 'muted' as const,
  MEDIA: 'info' as const,
  ALTA: 'warning' as const,
  URGENTE: 'destructive' as const,
};

export const financeStatusVariant = {
  PENDENTE: 'warning' as const,
  PAGO: 'success' as const,
  ATRASADO: 'destructive' as const,
  CANCELADO: 'muted' as const,
  RASCUNHO: 'muted' as const,
  EMITIDO: 'info' as const,
  VENCIDO: 'destructive' as const,
};

export const probExitoVariant = {
  BAIXA: 'destructive' as const,
  MEDIA: 'warning' as const,
  ALTA: 'success' as const,
};

export const integrationStatusVariant = {
  CONECTADO: 'success' as const,
  DESCONECTADO: 'muted' as const,
  ERRO: 'destructive' as const,
};

export const clientStatusVariant = {
  ATIVO: 'active' as const,
  INATIVO: 'muted' as const,
  PROSPECTO: 'info' as const,
};
