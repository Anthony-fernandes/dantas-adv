import { format, isSameDay, isSameMonth, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  BriefcaseBusiness,
  CalendarClock,
  FileClock,
  FolderKanban,
  Gavel,
  Handshake,
  ListTodo,
  MessageSquareMore,
  ReceiptText,
} from 'lucide-react';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { StatusBadge } from '@/components/shared/StatusBadge';
import { cn } from '@/lib/utils';
import { AGENDA_EVENT_TYPE_META } from './types';
import type { AgendaEvent } from './types';
import { formatAgendaEventDateRange, formatAgendaEventTimeLabel, isDeadlineSoon, isEventOverdue } from './utils';

type AgendaCalendarGridProps = {
  days: Date[];
  currentDate: Date;
  selectedDate: Date | null;
  eventsByDay: Map<string, AgendaEvent[]>;
  onSelectDate: (date: Date) => void;
  onEventClick: (event: AgendaEvent) => void;
  view: 'month' | 'week';
};

function getEventIcon(event: AgendaEvent) {
  switch (event.type) {
    case 'AUDIENCIA':
      return Gavel;
    case 'PRAZO_PROCESSUAL':
      return FileClock;
    case 'REUNIAO_CLIENTE':
      return Handshake;
    case 'REUNIAO_INTERNA':
      return BriefcaseBusiness;
    case 'TAREFA':
      return ListTodo;
    case 'PROTOCOLO':
      return ReceiptText;
    case 'CONSULTA':
      return MessageSquareMore;
    default:
      return FolderKanban;
  }
}

function getStatusVariant(event: AgendaEvent) {
  if (event.status === 'CANCELADO') return 'muted' as const;
  if (event.status === 'REALIZADO') return 'success' as const;
  if (event.status === 'ATRASADO' || isEventOverdue(event)) return 'destructive' as const;
  if (event.status === 'PENDENTE' || isDeadlineSoon(event)) return 'warning' as const;
  if (event.status === 'CONFIRMADO') return 'info' as const;
  return 'active' as const;
}

function AgendaEventPill({ event, onOpen }: { event: AgendaEvent; onOpen: (event: AgendaEvent) => void }) {
  const Icon = getEventIcon(event);
  const meta = AGENDA_EVENT_TYPE_META[event.type];

  return (
    <HoverCard openDelay={100} closeDelay={80}>
      <HoverCardTrigger asChild>
        <button
          type="button"
          onClick={(clickEvent) => {
            clickEvent.stopPropagation();
            onOpen(event);
          }}
          className="group w-full rounded-xl border px-2 py-1.5 text-left transition hover:-translate-y-[1px] hover:shadow-sm"
          style={{ backgroundColor: meta.surface, borderColor: meta.border }}
        >
          <div className="flex items-start gap-2">
            <span
              className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-md"
              style={{ backgroundColor: meta.color, color: '#fff' }}
            >
              <Icon className="h-3.5 w-3.5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[11px] font-semibold uppercase tracking-[0.16em]" style={{ color: meta.color }}>
                {formatAgendaEventTimeLabel(event)}
              </p>
              <p className="truncate text-xs font-medium text-foreground">{event.title}</p>
            </div>
          </div>
        </button>
      </HoverCardTrigger>

      <HoverCardContent align="start" className="w-[340px] space-y-3">
        <div className="space-y-2">
          <div className="flex items-start justify-between gap-3">
            <div className="space-y-1">
              <p className="text-sm font-semibold leading-tight">{event.title}</p>
              <p className="text-xs text-muted-foreground">{AGENDA_EVENT_TYPE_META[event.type].label}</p>
            </div>
            <StatusBadge variant={getStatusVariant(event)} dot={false}>
              {event.status}
            </StatusBadge>
          </div>

          <p className="text-xs text-muted-foreground">{formatAgendaEventDateRange(event)}</p>
        </div>

        <div className="grid gap-2 text-xs text-muted-foreground">
          {event.clientName ? (
            <div className="flex items-center justify-between gap-3">
              <span>Cliente</span>
              <span className="max-w-[180px] truncate font-medium text-foreground">{event.clientName}</span>
            </div>
          ) : null}

          {event.processNumber ? (
            <div className="flex items-center justify-between gap-3">
              <span>Processo</span>
              <span className="max-w-[180px] truncate font-medium text-foreground">{event.processNumber}</span>
            </div>
          ) : null}

          {event.responsibleName ? (
            <div className="flex items-center justify-between gap-3">
              <span>Responsável</span>
              <span className="max-w-[180px] truncate font-medium text-foreground">{event.responsibleName}</span>
            </div>
          ) : null}

          {event.location ? (
            <div className="flex items-center justify-between gap-3">
              <span>Local</span>
              <span className="max-w-[180px] truncate font-medium text-foreground">{event.location}</span>
            </div>
          ) : null}
        </div>

        {event.description ? (
          <div className="rounded-lg border bg-muted/40 p-3 text-xs text-muted-foreground">{event.description}</div>
        ) : null}
      </HoverCardContent>
    </HoverCard>
  );
}

export function AgendaCalendarGrid({
  days,
  currentDate,
  selectedDate,
  eventsByDay,
  onSelectDate,
  onEventClick,
  view,
}: AgendaCalendarGridProps) {
  const visibleLimit = view === 'week' ? 3 : 2;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-7 gap-2 text-center text-[11px] font-semibold uppercase tracking-[0.22em] text-muted-foreground">
        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'].map((label) => (
          <div key={label} className="rounded-xl bg-muted/40 px-3 py-2">
            {label}
          </div>
        ))}
      </div>

      <div className={cn('grid grid-cols-7 gap-2', view === 'week' && 'auto-rows-fr')}>
        {days.map((day) => {
          const key = format(day, 'yyyy-MM-dd');
          const events = eventsByDay.get(key) ?? [];
          const outsideMonth = view === 'month' && !isSameMonth(day, currentDate);
          const isToday = isSameDay(day, new Date());
          const isSelected = selectedDate ? isSameDay(day, selectedDate) : false;

          return (
            <button
              key={key}
              type="button"
              onClick={() => onSelectDate(day)}
              className={cn(
                'flex min-h-[160px] flex-col rounded-2xl border p-3 text-left transition hover:border-primary/50 hover:bg-accent/30',
                view === 'week' && 'min-h-[210px]',
                outsideMonth && 'bg-muted/30 text-muted-foreground',
                isSelected && 'border-primary ring-2 ring-primary/15',
                !outsideMonth && 'bg-background',
              )}
            >
              <div className="mb-3 flex items-start justify-between gap-2">
                <div>
                  <span
                    className={cn(
                      'inline-flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold',
                      isToday ? 'bg-primary text-primary-foreground shadow-sm' : 'bg-muted/50 text-foreground',
                      outsideMonth && 'bg-muted text-muted-foreground',
                    )}
                  >
                    {format(day, 'd')}
                  </span>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {format(day, "EEEE", { locale: ptBR }).slice(0, 3)}
                  </p>
                </div>

                {events.length > 0 ? (
                  <div className="rounded-full bg-muted px-2 py-1 text-[11px] font-medium text-muted-foreground">
                    {events.length} evento{events.length > 1 ? 's' : ''}
                  </div>
                ) : null}
              </div>

              <div className="flex-1 space-y-2">
                {events.slice(0, visibleLimit).map((event) => (
                  <AgendaEventPill key={event.id} event={event} onOpen={onEventClick} />
                ))}

                {events.length > visibleLimit ? (
                  <Popover>
                    <PopoverTrigger asChild>
                      <button
                        type="button"
                        className="inline-flex rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground transition hover:bg-muted/80"
                        onClick={(clickEvent) => clickEvent.stopPropagation()}
                      >
                        +{events.length - visibleLimit} mais
                      </button>
                    </PopoverTrigger>
                    <PopoverContent align="start" className="w-[340px] space-y-3 p-3">
                      <div>
                        <p className="text-sm font-semibold">{format(day, "dd 'de' MMMM", { locale: ptBR })}</p>
                        <p className="text-xs text-muted-foreground">Agenda completa do dia selecionado.</p>
                      </div>

                      <div className="space-y-2">
                        {events.map((event) => (
                          <AgendaEventPill key={event.id} event={event} onOpen={onEventClick} />
                        ))}
                      </div>
                    </PopoverContent>
                  </Popover>
                ) : null}
              </div>

              {events.length === 0 ? (
                <div className="mt-auto rounded-xl border border-dashed border-border/70 px-3 py-3 text-xs text-muted-foreground">
                  Nenhum compromisso programado.
                </div>
              ) : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}
